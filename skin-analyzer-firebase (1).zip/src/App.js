import React from "react";
import SkinAnalyzer from "./SkinAnalyzer";

function App() {
  return <SkinAnalyzer />;
}

export default App;