import React, { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "./firebaseConfig";

const skinTypes = ["Oily", "Dry", "Combination", "Normal", "Sensitive"];

const skinConcernsOptions = [
  "acne",
  "dryness",
  "pigmentation",
  "wrinkles",
  "sensitivity",
];

const skinData = {
  acne: ["Salicylic Acid", "Niacinamide", "Benzoyl Peroxide"],
  dryness: ["Hyaluronic Acid", "Ceramides", "Glycerin"],
  pigmentation: ["Vitamin C", "Azelaic Acid", "Kojic Acid"],
  wrinkles: ["Retinoids", "Peptides", "Antioxidants"],
  sensitivity: ["Panthenol", "Allantoin", "Centella Asiatica"],
};

export default function SkinAnalyzer() {
  const [skinType, setSkinType] = useState("");
  const [selectedConcerns, setSelectedConcerns] = useState([]);
  const [results, setResults] = useState([]);

  const handleSubmit = async () => {
    if (!skinType || selectedConcerns.length === 0) {
      alert("Please select skin type and at least one concern.");
      return;
    }

    const recommended = new Set();
    selectedConcerns.forEach((concern) => {
      if (skinData[concern]) {
        skinData[concern].forEach((item) => recommended.add(item));
      }
    });
    const recommendationsArray = [...recommended];
    setResults(recommendationsArray);

    try {
      await addDoc(collection(db, "skin_analyses"), {
        skinType,
        concerns: selectedConcerns,
        recommendations: recommendationsArray,
        createdAt: serverTimestamp(),
      });
      alert("Analysis saved successfully!");
    } catch (error) {
      console.error("Error saving analysis:", error);
      alert("Failed to save analysis.");
    }
  };

  const toggleConcern = (concern) => {
    if (selectedConcerns.includes(concern)) {
      setSelectedConcerns(selectedConcerns.filter((c) => c !== concern));
    } else {
      setSelectedConcerns([...selectedConcerns, concern]);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Skin Analyzer</h1>

      <div className="mb-4">
        <label className="block mb-1 font-semibold">Select your skin type:</label>
        <select
          className="w-full border p-2 rounded"
          value={skinType}
          onChange={(e) => setSkinType(e.target.value)}
        >
          <option value="">-- Select --</option>
          {skinTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>

      <div className="mb-4">
        <label className="block mb-1 font-semibold">Select your skin concerns:</label>
        {skinConcernsOptions.map((concern) => (
          <div key={concern}>
            <label>
              <input
                type="checkbox"
                checked={selectedConcerns.includes(concern)}
                onChange={() => toggleConcern(concern)}
              />
              <span className="ml-2 capitalize">{concern}</span>
            </label>
          </div>
        ))}
      </div>

      <button
        onClick={handleSubmit}
        className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
      >
        Analyze
      </button>

      {results.length > 0 && (
        <div className="mt-6 p-4 border rounded bg-gray-50">
          <h2 className="text-xl font-semibold mb-2">Recommended Ingredients:</h2>
          <ul className="list-disc list-inside">
            {results.map((item, idx) => (
              <li key={idx}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}